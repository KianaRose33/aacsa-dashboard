import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Dashboard() {
  return (
    <div className="p-6 grid gap-6">
      <h1 className="text-3xl font-bold">AACSA Program Associate Dashboard</h1>

      <Tabs defaultValue="monthly">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="monthly">📆 Monthly</TabsTrigger>
          <TabsTrigger value="weekly">🗓 Weekly</TabsTrigger>
          <TabsTrigger value="daily">📋 Daily</TabsTrigger>
          <TabsTrigger value="tracker">📊 Student Tracker</TabsTrigger>
          <TabsTrigger value="calendar">🗓️ Calendar</TabsTrigger>
        </TabsList>

        <TabsContent value="monthly">
          <Card>
            <CardContent className="space-y-4 p-4">
              <h2 className="text-xl font-semibold">Monthly Overview</h2>
              <ul className="list-disc list-inside">
                <li>Send ALA Newsletter (1st of each month)</li>
                <li>Submit monthly program reports</li>
                <li>Review program calendar and send to sponsors/funders</li>
                <li>Assign intern tasks and check deliverables</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="weekly">
          <Card>
            <CardContent className="space-y-4 p-4">
              <h2 className="text-xl font-semibold">Weekly Tasks</h2>
              <ul className="list-disc list-inside">
                <li>Monday: Planning Meeting, Intern Task Assignment</li>
                <li>Tuesday: Outreach & School Engagement</li>
                <li>Wednesday: Marketing & Flyers</li>
                <li>Thursday: Mentorship & Data</li>
                <li>Friday: Admin Wrap-Up & Summary Email</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="daily">
          <Card>
            <CardContent className="space-y-4 p-4">
              <h2 className="text-xl font-semibold">Daily EOD Report</h2>
              <Input placeholder="Summary of Tasks Completed" />
              <Input placeholder="Hours per Program (ALA, STEAM, etc.)" />
              <Input placeholder="Emails/Meetings" />
              <Input placeholder="Roadblocks or Needs" />
              <Input placeholder="Follow-Ups for Tomorrow" />
              <Button className="mt-4">Submit EOD Report</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tracker">
          <Card>
            <CardContent className="space-y-4 p-4">
              <h2 className="text-xl font-semibold">Student Tracker</h2>
              <p>Access and manage your ALA student tracker via the Google Sheets link below:</p>
              <a 
                href="https://docs.google.com/spreadsheets/d/1-4QZnkijVSKWc3EtdW8vUzLX6OTfq_7zI9FJ9oKKceY/edit?gid=590030332" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-blue-600 underline"
              >
                Open Student Tracker
              </a>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="calendar">
          <Card>
            <CardContent className="space-y-4 p-4">
              <h2 className="text-xl font-semibold">Google Calendar</h2>
              <iframe 
                src="https://calendar.google.com/calendar/embed?src=kiana.munoz%40sjaacsa.org" 
                style={{ border: 0 }} 
                width="800" 
                height="600" 
                frameBorder="0" 
                scrolling="no"
              ></iframe>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
