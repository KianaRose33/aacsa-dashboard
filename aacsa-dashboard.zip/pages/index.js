import Dashboard from '../components/ui/Dashboard';
export default function Home() {
  return <Dashboard />;
}
